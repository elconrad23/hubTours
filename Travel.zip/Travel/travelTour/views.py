from django.shortcuts import render, redirect
from .models import Destination,Tours,Activity,means,rental_cars,buses,flights,package,Hotel,Room
from .forms import ExampleForm
import json
import urllib.request
import requests
from django.template.loader import render_to_string
from django.conf import settings
from django.core.mail import EmailMessage
from django.views.generic import TemplateView

# Create your views here.
def index(request):
    dests = Destination.objects.all()
    url = 'http://api.openweathermap.org/data/2.5/weather?q={}&units=imperial&appid=8b98ebd6cdbe87936f69f974a89db8c3'

    city = 'Kampala'
    city_weather=requests.get(url.format(city)).json()
    weather1 = {
        'city':city,
        'temperature':city_weather['main']['temp'],
        'description':city_weather['weather'][0]['description'],
        'icon':city_weather['weather'][0]['icon']
    }
    city = 'Paris'
    city_weather=requests.get(url.format(city)).json()
    weather2 = {
        'city':city,
        'temperature':city_weather['main']['temp'],
        'description':city_weather['weather'][0]['description'],
        'icon':city_weather['weather'][0]['icon']
    }
    city = 'Maldives'
    city_weather=requests.get(url.format(city)).json()
    weather3 = {
        'city':city,
        'temperature':city_weather['main']['temp'],
        'description':city_weather['weather'][0]['description'],
        'icon':city_weather['weather'][0]['icon']
    }
    city = 'Saxony'
    city_weather=requests.get(url.format(city)).json()
    weather4 = {
        'city':city,
        'temperature':city_weather['main']['temp'],
        'description':city_weather['weather'][0]['description'],
        'icon':city_weather['weather'][0]['icon']
    }
    city = 'Victoria'
    city_weather=requests.get(url.format(city)).json()
    weather5 = {
        'city':city,
        'temperature':city_weather['main']['temp'],
        'description':city_weather['weather'][0]['description'],
        'icon':city_weather['weather'][0]['icon']
    }
    

    return render(request,"index.html",{'dests':dests,'weather1':weather1,'weather2':weather2,'weather3':weather3,'weather4':weather4,'weather5':weather5}) 

def Uganda(request):
    
    desT = request.POST.get('desT')

    tours = Tours.objects.filter(name=desT)

    return render(request, "Uganda.html",{'tours':tours,'desT' : desT}) 

def dates(request):
    
    form2=ExampleForm(request.POST)
    return render(request,"dates.html",{"form2":form2})

def weather(request):
    url = 'http://api.openweathermap.org/data/2.5/weather?q={}&units=imperial&appid=8b98ebd6cdbe87936f69f974a89db8c3'

    city = 'Kampala'
    city_weather=requests.get(url.format(city)).json()
    weather = {
        'city':city,
        'temperature':city_weather['main']['temp'],
        'description':city_weather['weather'][0]['description'],
        'icon':city_weather['weather'][0]['icon']
    }

    context = {'weather':weather}
    print(city_weather)
    return render(request,'weather.html',context)    

def activitiesList(request): 
    if request.method == "POST":
        activity = Activity(
            #img=request.POST['img'],
            
                description=request.POST['desc'],
                price=request.POST['price'],
                name=request.POST['name'],
                number=request.POST.get('number'),
                result=int(request.POST.get('number'))*int(request.POST['price'])
        )
        activity.save()

        activities=Activity.objects.all()
        return render(request,'activitiesList.html',{'activities':activities}) 
    else:
        activities=Activity.objects.all()
        return render(request,'activitiesList.html',{'activities':activities}) 

def remove(request):
    name = request.POST['desc']
    act=Activity.objects.filter(description=name)
    act.delete()
    
    activities=Activity.objects.all()
    return render(request,'activitiesList.html',{'activities':activities}) 
def transport(request):
   dets = means.objects.all()
   return render(request,'transport.html', {'dets':dets})
def rental(request):
   car = rental_cars.objects.all()
   return render(request,'rental.html',{'rental':car})
def bus(request):
   bus = buses.objects.all()
   return render(request,'bus.html',{'bus':bus})
def flight(request):
   flight = flights.objects.all()
   return render(request,'flight.html',{'flight':flight})
def sidebar(request):
   
   return render(request,'sidebar.html')
def addDestination(request):
   
   return render(request,'addDestination.html')

def addMeans(request):
   
   return render(request,'addMeans.html')
def addTourActivity(request):
   
   return render(request,'addTourActivity.html')
def addTourActivity(request):
   
   return render(request,'addTourActivity.html')
def addbus(request):
   
   return render(request,'addbus.html')
def addrentalcar(request):
   
   return render(request,'addrentalcar.html')
def addflight(request):
   
   return render(request,'addflight.html')
def addhotel(request):
   
   return render(request,'addhotel.html')
def destData(request): 
    if request.method == "POST":
        dests = Destination(
            #img=request.POST['img'],
            
                desc=request.POST['desc'],                
                name=request.POST['name'],
                img=request.FILES['img'],
                
        )
        dests.save()

        
        return render(request,'addDestination.html') 

def tourData(request): 
    if request.method == "POST":
        tours = Tours(
            #img=request.POST['img'],
            
                description=request.POST['description'],                
                name=request.POST['name'],
                price=request.POST['price'],
                img=request.FILES['img'],
                
        )
        tours.save()

        
        return render(request,'addTourActivity.html') 

def meansData(request): 
    if request.method == "POST":
        mean = means(
            #img=request.POST['img'],
            
                desc=request.POST['desc'],                
                name=request.POST['name'],
                offer=request.POST['offer'],
                url=request.POST['url'],
                img=request.FILES['img'],
                
        )
        mean.save()

        
        return render(request,'addMeans.html') 
def rentalData(request): 
    if request.method == "POST":
        cars = rental_cars(
            #img=request.POST['img'],
            
                car_name=request.POST['car_name'],                
                name=request.POST['name'],
                price=request.POST['price'],
                img=request.FILES['img'],
                
        )
        cars.save()

        
        return render(request,'addrentalcar.html') 

def flightData(request): 
    if request.method == "POST":
        flight = flights(
            #img=request.POST['img'],
            
                flightname=request.POST['flightname'],                
                name=request.POST['name'],
                price=request.POST['price'],
                img=request.FILES['img'],
                
        )
        flight.save()

        
        return render(request,'addflight.html') 
def busData(request): 
    if request.method == "POST":
        bus = buses(
            #img=request.POST['img'],
            
                busname=request.POST['busname'],                
                name=request.POST['name'],
                price=request.POST['price'],
                img=request.FILES['img'],
                
        )
        bus.save()

        
        return render(request,'addbus.html')                 
def customerLogin(request):
   
   return render(request,'customerLogin.html') 

def customer_createPage(request):
   
   return render(request,'customer_createPage.html') 

def accommodation(request):
    dest = request.POST.get('dest')
    hotels = Hotel.objects.all()
    print(dest)
    return render(request,'accommodation.html',{'hotels':hotels, 'dest':dest}) 
def bookRoom(request):
    hotel = request.POST.get('hotelname')
    rooms = Room.objects.all()
    return render(request,'bookRoom.html',{'rooms':rooms, 'hotel':hotel})   

#used in invoice 
def multiply(price, qty):
    return (price * qty)

#used in invoice
def add(sic, doc, soc):
    return (sic + doc + soc)

def invoices(request):
   if request.method=='POST':
    hotel = request.POST.get('hotelname')
    guest = request.POST.get('guest')
    single = request.POST.get('single')
    double = request.POST.get('double')
    suite = request.POST.get('suite')
    rooms = Room.objects.all()
    for room in rooms:
       if room.Hotel_name == hotel:
          single_charge = multiply(room.Single_price, int(single))
          double_charge = multiply(room.Double_price, int(double))
          suite_charge = multiply(room.Suite_price, int(suite))

    total_charge = add(single_charge, double_charge, suite_charge)

    context= {
        'hotel': hotel,
        'guest': guest,
        'single': single,
        'single_charge': single_charge,
        'double' : double,
        'double_charge': double_charge,
        'suite': suite,
        'suite_charge': suite_charge,
        'total_charge': total_charge
     }
   return render(request,'invoices.html',context)       

def pay(request):
   
   return render(request,'pay.html')     

# def register(request):
#     email = request.POST['email']
#     html_template='html_template.html'
#     html_message = render_to_string(html_template)
#     subject='Welcome to Travel'
#     email_from = settings.EMAIL_HOST_USER
#     recipient_list = [email]
#     message = EmailMessage(subject, html_message, email_from, recipient_list) 
#     message.content_subtype='html'
#     message.send()
#     return redirect('customerLogin')



#Ayiko added this while you were for lunch 
def pac(request):
   pack = package.objects.all()
   return render(request,'package.html',{'pack':pack})

# class Home(TemplateView):
#     template_name = 'index.html'

#def allActivities 