from django import forms
from django.forms import ModelForm,TextInput

class DateInput(forms.DateInput):
    input_type = 'date' 

class ExampleForm(forms.Form):
    my_date_field = forms.DateField(widget=DateInput)    

