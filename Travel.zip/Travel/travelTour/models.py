from django.db import models

# Create your models here.

class Destination(models.Model):
    
    name=models.CharField(max_length=100)
    img= models.ImageField(upload_to='pics')
    desc= models.TextField()
   
    #offer = models.BooleanField(default=False)

class Tours(models.Model):
      img= models.ImageField(upload_to='pics')
      description=models.TextField() 
      price= models.IntegerField()
      name=models.CharField(max_length=100)

class Activity(models.Model):
      img= models.ImageField(upload_to='pics')
      description=models.TextField() 
      price= models.IntegerField()
      name=models.CharField(max_length=100)
      number=models.IntegerField()
      result=models.IntegerField()

class means(models.Model):
    name= models.CharField(max_length=100)
    img= models.ImageField(upload_to = 'pics')
    desc= models.TextField()
    offer= models.BooleanField(default = False)
    url = models.CharField(max_length=255)
    
class rental_cars(models.Model):
    name = models.CharField(max_length=100)
    car_name = models.CharField(max_length = 100)
    price = models.IntegerField()
    img = models.ImageField(upload_to ='pics')
    
class buses(models.Model):
    name = models.CharField(max_length=100)
    busname = models.CharField(max_length = 100)
    price = models.IntegerField()
    img = models.ImageField(upload_to ='pics')
    
class flights(models.Model):
    name = models.CharField(max_length=100)
    flightname = models.CharField(max_length = 100)
    price = models.IntegerField()
    img = models.ImageField(upload_to ='pics')

#@Ayiko addded this whihe you were for breakfast
class package(models.Model):
    place = models.CharField(max_length=100)
    transportation = models.CharField(max_length=100)
    accomodation =  models.CharField(max_length=100)
    desc= models.TextField()
    img= models.ImageField(upload_to = 'pics')
    price= models.IntegerField()
    offer= models.BooleanField(default = False)
class Hotel(models.Model):
    Hotel_dest = models.CharField(max_length=50)
    Hotel_name = models.CharField(max_length=50)
    Hotel_image = models.ImageField(upload_to='image')
    
class Room(models.Model):
    Hotel_name = models.CharField(max_length=50)
    Single_image = models.ImageField(upload_to='image')
    Single_price = models.IntegerField()
    Double_image = models.ImageField(upload_to='image')
    Double_price = models.IntegerField()
    Suite_image = models.ImageField(upload_to='image')
    Suite_price = models.IntegerField()

    