from django.contrib import admin
from .models import Destination,Tours,Activity,buses, means, flights, rental_cars,package,Hotel, Room

# Register your models here.
admin.site.register(Destination)
admin.site.register(Tours)
admin.site.register(Activity)
admin.site.register(means)
admin.site.register(rental_cars)
admin.site.register(buses)
admin.site.register(flights)
admin.site.register(package)
admin.site.register(Hotel)
admin.site.register(Room)