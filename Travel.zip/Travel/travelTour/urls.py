from django.contrib import admin
from django.urls import path,include
from . import views
#from .views import Home

urlpatterns = [
    #path('', Index.as_view(), name='index'),
    path("", views.index, name="index"),
    path('accounts/', include('allauth.urls')),
    path("Uganda",views.Uganda, name="Uganda"),
    path("dates",views.dates, name="dates"),
    path("weather",views.weather, name="weather"),
    path("activitiesList",views.activitiesList, name="activitiesList"),
    path("remove",views.remove, name="remove"),
    path('transport',views.transport,name='transport'),
    path('rental',views.rental,name='rental'),
    path('bus',views.bus,name='bus'),
    path('flight',views.flight,name='flight'),
    path('sidebar',views.sidebar,name='sidebar'),
    path('addDestination',views.addDestination,name='addDestination'),
    path('addMeans',views.addMeans,name='addMeans'),
    path('addTourActivity',views.addTourActivity,name='addTourActivity'),
    path("addbus", views.addbus, name="addbus"),
    path("addflight", views.addflight, name="addflight"),
    path("addrentalcar", views.addrentalcar, name="addrentalcar"),
    path("addhotel", views.addhotel, name="addhotel"),
    path("destData", views.destData, name="destData"),
    path("tourData", views.tourData, name="tourData"),
    path("meansData", views.meansData, name="meansData"),
    path("rentalData", views.rentalData, name="rentalData"),
    path("flightData", views.flightData, name="flightData"),
    path("busData", views.busData, name="busData"),
    path("customerLogin", views.customerLogin, name="customerLogin"),
    path("customer_createPage", views.customer_createPage, name="customer_createPage"),
    path("accommodation", views.accommodation, name="accommodation"),
    path("bookRoom", views.bookRoom, name="bookRoom"),
    path("invoices", views.invoices, name="invoices"),
    path("pay", views.pay, name="pay"),
    #path("register", views.register, name="register"),
    path('pac',views.pac,name='pac'),
    
]
