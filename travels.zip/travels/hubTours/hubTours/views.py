from django.views.generic import TemplateView

class Home(TemplateView):
    template_name = 'home.html'
    
class Destinations(TemplateView):
    template_name = 'destinations.html'
    
class News(TemplateView):
    template_name = 'news.html'
    
# class Home(TemplateView):
#     template_name = 'home.html'